-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 13, 2024 at 05:18 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `educaapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumnos`
--

CREATE TABLE `alumnos` (
  `Matricula` int(11) NOT NULL,
  `Nombre` varchar(20) DEFAULT NULL,
  `Apellido` varchar(40) DEFAULT NULL,
  `Id_materias` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alumnos`
--

INSERT INTO `alumnos` (`Matricula`, `Nombre`, `Apellido`, `Id_materias`) VALUES
(55, 'Roberto', 'Rosado', 6),
(77, 'Jose', 'Ramos', 6),
(20230627, 'Juana', 'Ramirez', 6),
(45456254, 'Mariy', 'Alcantara', 6),
(245444455, 'Rafaela', 'Perez', 6);

-- --------------------------------------------------------

--
-- Table structure for table `asistencia`
--

CREATE TABLE `asistencia` (
  `Id_asistencia` int(11) NOT NULL,
  `Fecha` varchar(20) DEFAULT NULL,
  `Asisitio` varchar(4) DEFAULT NULL,
  `Matricula` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `asistencia`
--

INSERT INTO `asistencia` (`Id_asistencia`, `Fecha`, `Asisitio`, `Matricula`) VALUES
(4, '2026-7-2', 'SI', 55),
(5, '2024-5-11', 'SI', 55),
(6, '2024-5-11', 'NO', 77),
(7, '2024-5-11', 'SI', 77),
(8, '2024-5-11', 'SI', 77),
(9, '2024-5-11', 'SI', 20230627),
(10, '2024-5-11', 'SI', 77),
(11, '2024-5-11', 'SI', 77),
(12, '2024-5-11', 'SI', 20230627);

-- --------------------------------------------------------

--
-- Table structure for table `calificaciones`
--

CREATE TABLE `calificaciones` (
  `Id_calificaciones` int(11) NOT NULL,
  `Asignacion` decimal(10,0) DEFAULT NULL,
  `Practica` decimal(10,0) DEFAULT NULL,
  `Examen` decimal(10,0) DEFAULT NULL,
  `Total` decimal(10,0) DEFAULT NULL,
  `Id_matricula` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `calificaciones`
--

INSERT INTO `calificaciones` (`Id_calificaciones`, `Asignacion`, `Practica`, `Examen`, `Total`, `Id_matricula`) VALUES
(5, 0, 0, 0, 0, 55),
(6, 0, 0, 0, 0, 77),
(7, 0, 0, 0, 0, 20230627),
(8, 0, 0, 0, 0, 245444455),
(9, 0, 0, 0, 0, 45456254);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Id` int(11) NOT NULL,
  `Maestro` varchar(25) DEFAULT NULL,
  `Contrasena` varchar(40) DEFAULT NULL,
  `Primera_mascota` varchar(30) DEFAULT NULL,
  `Prim_fav` varchar(30) DEFAULT NULL,
  `Lugar_nacimineto` varchar(60) DEFAULT NULL,
  `nuevoIngreso` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Id`, `Maestro`, `Contrasena`, `Primera_mascota`, `Prim_fav`, `Lugar_nacimineto`, `nuevoIngreso`) VALUES
(1, 'Ronny', '1234', 'Luna', 'Luisa', 'San Juan', 1);

-- --------------------------------------------------------

--
-- Table structure for table `materia`
--

CREATE TABLE `materia` (
  `Id` int(11) NOT NULL,
  `Nom_materia` varchar(60) DEFAULT NULL,
  `Id_maestro` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `materia`
--

INSERT INTO `materia` (`Id`, `Nom_materia`, `Id_maestro`) VALUES
(6, 'SOFTWARE', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`Matricula`),
  ADD KEY `AlumnosIdMaterias_Materias` (`Id_materias`);

--
-- Indexes for table `asistencia`
--
ALTER TABLE `asistencia`
  ADD PRIMARY KEY (`Id_asistencia`),
  ADD KEY `Asistencia_fk_Alumno` (`Matricula`);

--
-- Indexes for table `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD PRIMARY KEY (`Id_calificaciones`),
  ADD KEY `Calificaciones_fk_Alumno` (`Id_matricula`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `materia`
--
ALTER TABLE `materia`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `MaestrofkLogin` (`Id_maestro`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `asistencia`
--
ALTER TABLE `asistencia`
  MODIFY `Id_asistencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `calificaciones`
--
ALTER TABLE `calificaciones`
  MODIFY `Id_calificaciones` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `materia`
--
ALTER TABLE `materia`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alumnos`
--
ALTER TABLE `alumnos`
  ADD CONSTRAINT `AlumnosIdMaterias_Materias` FOREIGN KEY (`Id_materias`) REFERENCES `materia` (`Id`);

--
-- Constraints for table `asistencia`
--
ALTER TABLE `asistencia`
  ADD CONSTRAINT `Asistencia_fk_Alumno` FOREIGN KEY (`Matricula`) REFERENCES `alumnos` (`Matricula`);

--
-- Constraints for table `calificaciones`
--
ALTER TABLE `calificaciones`
  ADD CONSTRAINT `Calificaciones_fk_Alumno` FOREIGN KEY (`Id_matricula`) REFERENCES `alumnos` (`Matricula`);

--
-- Constraints for table `materia`
--
ALTER TABLE `materia`
  ADD CONSTRAINT `MaestrofkLogin` FOREIGN KEY (`Id_maestro`) REFERENCES `login` (`Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
