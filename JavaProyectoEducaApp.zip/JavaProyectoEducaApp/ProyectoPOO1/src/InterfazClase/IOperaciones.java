
package InterfazClase;

public interface IOperaciones {
    public abstract double sumaTotal();
}
