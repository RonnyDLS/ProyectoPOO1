
package ClassAbstract;

public abstract class Calificaciones {
    protected double ptObte;
    protected double pt;
    
    public Calificaciones() {
    }

    public Calificaciones(double ptObte, double pt) {
        this.ptObte = ptObte;
        this.pt = pt;
    }
    
}
