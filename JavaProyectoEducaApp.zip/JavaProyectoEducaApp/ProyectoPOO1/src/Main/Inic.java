
package Main;

import Interfaces.AsistenciaAlumnos;
import Interfaces.Binvenida;
import Interfaces.CalificacionesEstudiantes;
import Interfaces.CrearClases;
import Interfaces.GestionEstudiantes;
import Interfaces.LoginMaestros;
import Interfaces.Materias;
import Interfaces.UnaVezRecupContrasena;
import java.time.LocalDate;

public class Inic {
    public static void main(String[] args) {
        LoginMaestros iniciar = new LoginMaestros();
        //Binvenida ini = new Binvenida();
        //AgregarAlumnos i = new AgregarAlumnos();
        //Materias iniciarMaterias = new Materias();
        //iniciarMaterias.setVisible(true);
        //Plantilla i = new GestionEstudiantes();
        //Asistencia i = new Asistencia();
        //CalificacionesEstudiantes i= new CalificacionesEstudiantes();
        //GestionEstudiantes in = new GestionEstudiantes();
        //GestionEstudiantes i = new GestionEstudiantes();
        //RecuperacionDeContasena in = new RecuperacionDeContasena();
        //UnaVezRecupContrasena inic = new UnaVezRecupContrasena();
        //CambiarContrasenaLogin iniciar = new CambiarContrasenaLogin();
        //Asistencia i = new Asistencia();
        //AsistenciaAlumnos a = new AsistenciaAlumnos();
        //EditarGestion e = new EditarGestion();
        //CrearClases clase = new CrearClases();
          
    }
    
}
