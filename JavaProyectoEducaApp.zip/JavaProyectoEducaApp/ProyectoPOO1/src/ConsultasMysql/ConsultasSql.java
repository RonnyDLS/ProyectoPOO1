
package ConsultasMysql;

public class ConsultasSql {
    public static String DatosLogin = "select * from login";
    public static String eliminarAllMateria = "TRUNCATE TABLE materia ";
    public static String eliminarAllAlumno = "TRUNCATE TABLE alumnos";
    public static String allAlumnos = "select* from alumnos";
}
